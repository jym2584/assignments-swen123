"""
Practice problems for SWEC 123.07
Topic: Python Dictionaries
"""

def create_dicts(filename):
    # create two dictionaries 
    # one for players as the key and their team(s) as the value 
    # *HINT* Some players have played for multiple teams
    # one for players as the key and their amount of rings as the value

    nba_players = dict()
    player_rings = dict()
    player_status = dict()
    
    with open(filename) as file:
        for line in file:
            info = line.strip().split(",")

            player = info[0].strip()
            team = info[1].strip().split()
            rings = int(info[2].strip())
            status = info[3].strip()
            
            nba_players[player] = team
            player_rings[player] = rings
            player_status[player] = status

            # ask the students about switching the team to the key
            # and how we would need to change the code to represent 
            # that
                
    return nba_players, player_rings, player_status

def find_loyalty(nba_players):
    # find and print out the players who only stayed with one team

    print("One Team Men:")
    for player in nba_players:
        if len(nba_players[player]) == 1:
            print(player)
    print() 

def multiple_teams(nba_players):
    # find and print out the players who played for multiple teams

    print("Journey Men:")
    for player in nba_players:
        if len(nba_players[player]) > 1:
            print(player)
    print()

def find_champs(player_rings):
    # find and print out the players who have won championship(s)

    print("Winners:")
    for player in player_rings:
        if player_rings[player] > 0:
            print(player)
    print()

def find_active(player_status):
    # find and print out the players who are currently active

    print("Currently Active:")
    for player in player_status:
        if player_status[player] == "Active":
            print(player)

def main():
    nba_players, player_rings, player_status = create_dicts("nba_players.txt")
    find_loyalty(nba_players)
    multiple_teams(nba_players)
    find_champs(player_rings)
    find_active(player_status)

if __name__ == "__main__":
    main()
"""
Practice problems for SWEC 123.07
Topic: Python Dictionaries
"""

def create_dicts(filename):
    # create three dictionaries 
    # one with their name as the key and their team(s) as the value 
    # *HINT* Some players have played for multiple teams
    # one with their name as the key and their amount of rings as the value 
    # one with their name as the key and their status as the value


    pass

def find_loyalty(nba_players):
    # find and print out the players who only stayed with one team
    
    pass

def multiple_teams(nba_players):
    # find and print out the players who played for multiple teams
    
    pass

def find_champs(player_rings):
    # find and print out the players who have won championship(s)
    
    pass

def find_active(player_status):
    # find and print out the players who are currently active
    
    pass

def main():
    pass

if __name__ == "__main__":
    main()